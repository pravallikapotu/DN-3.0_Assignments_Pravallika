
public interface Image {
    void display();
}
